import numpy as np
import pandas as pd
import torch
from data import load_adult
from train import train
from metrics import evaluate

data = load_adult(val_size=0.2)
test = (data["X_test"], data["y_test"], data["z_test"])
val = (data["X_val"], data["y_val"], data["z_val"])
P_base, _ = train(data, debias=False, epochs=20, verbose=False)
P_dp, _ = train(data, mode="parity", alpha=1.0, epochs=20, verbose=False)

# baseline scores on the VALIDATION set
P_base.eval()
with torch.no_grad():
    pv = torch.sigmoid(P_base(data["X_val"])).cpu().numpy()
zv = data["z_val"].numpy()

# keep 0.5 for men; lower women's threshold until their positive rate matches men's
rate_m = np.mean(pv[zv == 1] >= 0.5)
t_f = np.quantile(pv[zv == 0], 1 - rate_m)
print(f"men's positive rate on val: {rate_m:.3f}  ->  women's threshold: {t_f:.3f}")
print(f"val DP gap with these thresholds: {evaluate(P_base, *val, threshold=(0.5, t_f))['DP gap']:.4f}")

rows = {"Baseline (t = 0.5)": evaluate(P_base, *test),
        f"Baseline, t_M = 0.5, t_F = {t_f:.3f}": evaluate(P_base, *test, threshold=(0.5, t_f)),
        "Adversarial parity (t = 0.5)": evaluate(P_dp, *test)}
pd.set_option("display.width", 250); pd.set_option("display.max_columns", None)
print(pd.DataFrame(rows).T.round(4))