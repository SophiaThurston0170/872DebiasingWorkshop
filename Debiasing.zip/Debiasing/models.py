
import torch
import torch.nn as nn


class Predictor(nn.Module):
    def __init__(self, n_in, hidden=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(n_in, hidden), nn.ReLU(),
            nn.Linear(hidden, hidden), nn.ReLU(),
            nn.Linear(hidden, 1))

    def forward(self, x, return_hidden=False):
        h = self.net[:4](x)                    # Linear-ReLU-Linear-ReLU -> 64 numbers
        logit = self.net[4](h).squeeze(-1)     # final Linear -> logit
        return (logit, h) if return_hidden else logit

class Adversary(nn.Module):
    def __init__(self, mode="eq_odds", hidden=0):
        super().__init__()
        assert mode in ("parity", "eq_odds", "eq_opp", "repr")
        self.mode = mode
        self.c = nn.Parameter(torch.ones(1))
        n_in = {"eq_odds": 4, "repr": 64}.get(mode, 1)
        if hidden:   # Q6: one hidden layer
            self.lin = nn.Sequential(nn.Linear(n_in, hidden), nn.ReLU(), nn.Linear(hidden, 1))
        else:
            self.lin = nn.Linear(n_in, 1)

    def forward(self, y_logit, y_true):
        if self.mode == "repr":               
            return self.lin(y_logit).squeeze(-1)
        s = torch.sigmoid((1 + self.c.abs()) * y_logit)
        if self.mode == "eq_odds":
            feats = torch.stack([s, s * y_true, s * (1 - y_true), y_true], dim=-1)
        else:
            feats = s.unsqueeze(-1)
        return self.lin(feats).squeeze(-1)         # logit for z

class GradReverse(torch.autograd.Function):
    """Identity in the forward pass; multiplies the gradient by -alpha in the backward pass."""

    @staticmethod
    def forward(ctx, x, alpha):
        ctx.alpha = alpha               # remember alpha for the backward pass
        return x.view_as(x)             # same values, new tensor

    @staticmethod
    def backward(ctx, grad_output):
        return -ctx.alpha * grad_output, None   # one gradient per input; alpha needs none