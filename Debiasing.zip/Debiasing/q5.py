import pandas as pd
from sklearn.linear_model import LogisticRegression
from data import load_adult

data = load_adult()
X, y, z = (t.numpy() for t in data["train_ds"].tensors)

corr = pd.DataFrame(X, columns=data["feature_names"]).corrwith(pd.Series(z)).dropna()
print(corr.reindex(corr.abs().sort_values(ascending=False).index).head(15).round(3))

clf = LogisticRegression(max_iter=2000).fit(X, z)
Xt, zt = data["X_test"].cpu().numpy(), data["z_test"].numpy()
print(f"\npredicting from X: accuracy {clf.score(Xt, zt):.3f}"
      f"   (always guessing z=1: {max(zt.mean(), 1 - zt.mean()):.3f})")