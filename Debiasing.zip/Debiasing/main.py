import matplotlib
matplotlib.use("Agg")                      # save figures to files (works with !python)
import matplotlib.pyplot as plt
import pandas as pd

from data import load_adult, set_seed
from metrics import evaluate
from train import train

EPOCHS = 20
ALPHA = 1.0

if __name__ == "__main__":
    set_seed()
    data = load_adult()
    print("Using device:", data["device"])
    test = (data["X_test"], data["y_test"], data["z_test"])

    print("\n=== 1. Baseline (no debiasing) ===")
    P_base, hist_base = train(data, debias=False, epochs=EPOCHS)

    print("\n=== 2. Debiased: demographic parity ===")
    P_dp, hist_dp = train(data, mode="parity", alpha=ALPHA, epochs=EPOCHS)

    print("\n=== 3. Debiased: equalized odds ===")
    P_eo, hist_eo = train(data, mode="eq_odds", alpha=ALPHA, epochs=EPOCHS)

    results = pd.DataFrame({
        "Baseline":              evaluate(P_base, *test),
        "Debiased: parity":      evaluate(P_dp, *test),
        "Debiased: equal. odds": evaluate(P_eo, *test),
    }).T
    pd.set_option("display.width", 200); pd.set_option("display.max_columns", None)
    print("\n=== Results on the test set (gaps: lower = fairer) ===")
    print(results.round(4))
    results.to_csv("results.csv")

    metrics = ["accuracy", "DP gap", "TPR gap", "FPR gap"]
    ax = results[metrics].T.plot(kind="bar", figsize=(9, 4), rot=0)
    ax.set_title("Baseline vs adversarial debiasing")
    ax.set_ylabel("value  (gaps: lower = fairer)")
    plt.tight_layout(); plt.savefig("comparison.png", dpi=120); plt.close()

    fig, axes = plt.subplots(1, 4, figsize=(18, 4))
    for h, name in [(hist_base, "Baseline"), (hist_dp, "Parity"), (hist_eo, "Equal. odds")]:
        for ax, m in zip(axes, metrics):
            ax.plot(h["epoch"], h[m], label=name)
    for ax, m in zip(axes, metrics):
        ax.set_title(f"Test {m}"); ax.set_xlabel("epoch"); ax.legend()
    plt.tight_layout(); plt.savefig("curves.png", dpi=120); plt.close()

    print("\nSaved: results.csv, comparison.png, curves.png")

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(hist_dp["epoch"], hist_dp["loss_A"], "o-", label="parity")
    ax.plot(hist_eo["epoch"], hist_eo["loss_A"], "o-", label="equalized odds")
    ax.set_xlabel("epoch"); ax.set_ylabel("L_A"); ax.legend()
    plt.tight_layout(); plt.savefig("loss_A.png", dpi=120); plt.close()
    
    import numpy as np
    _, y_tr, z_tr = (t.numpy() for t in data["train_ds"].tensors)
    H = lambda p: -(p * np.log(p) + (1 - p) * np.log(1 - p))
    print("parity floor   H(z)   =", H(z_tr.mean()))
    print("eq_odds floor  H(z|y) =", sum((y_tr == v).mean() * H(z_tr[y_tr == v].mean()) for v in (0, 1)))
    
    import torch
    z = data["z_test"].numpy()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4), sharey=True)
    for ax, (P, name) in zip(axes, [(P_base, "Baseline"), (P_dp, "Parity")]):
        P.eval()
        with torch.no_grad():
            p = torch.sigmoid(P(data["X_test"])).cpu().numpy()
        ax.hist(p[z == 1], bins=40, range=(0, 1), density=True, alpha=0.5, label="z=1")
        ax.hist(p[z == 0], bins=40, range=(0, 1), density=True, alpha=0.5, label="z=0")
        ax.axvline(0.5, color="k", lw=1)          # the decision threshold
        ax.set_title(name); ax.set_xlabel("sigmoid(P(x))"); ax.legend()
    plt.tight_layout(); plt.savefig("scores.png", dpi=120); plt.close()