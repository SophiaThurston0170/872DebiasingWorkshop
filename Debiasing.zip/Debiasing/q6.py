import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from data import load_adult
from train import train
from metrics import evaluate

data = load_adult()
test = (data["X_test"], data["y_test"], data["z_test"])
rows, stab, hists = {}, {}, {}
for mode in ["parity", "eq_odds"]:
    for hidden in [0, 32]:
        name = f"{mode}, {'linear' if hidden == 0 else 'hidden 32'} A"
        P, h = train(data, mode=mode, alpha=1.0, epochs=20, adv_hidden=hidden, verbose=False)
        rows[name], hists[name] = evaluate(P, *test), h
        stab[name] = h[["accuracy", "DP gap", "TPR gap", "loss_A"]].tail(10).std()   # wobble, last 10 epochs
        print("done:", name)

pd.set_option("display.width", 250); pd.set_option("display.max_columns", None)
print(pd.DataFrame(rows).T.round(4))
print("\nStd over the last 10 epochs (lower = more stable):")
print(pd.DataFrame(stab).T.round(4))

fig, axes = plt.subplots(1, 3, figsize=(16, 4))
for name, h in hists.items():
    for ax, m in zip(axes, ["DP gap", "TPR gap", "loss_A"]):
        ax.plot(h["epoch"], h[m], label=name)
for ax, m in zip(axes, ["DP gap", "TPR gap", "loss_A"]):
    ax.set_title(m); ax.set_xlabel("epoch"); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig("q6_curves.png", dpi=120); plt.close()