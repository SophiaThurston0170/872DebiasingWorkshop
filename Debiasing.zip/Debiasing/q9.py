import pandas as pd
from data import load_adult
from train import train
from metrics import evaluate

data = load_adult()
test = (data["X_test"], data["y_test"], data["z_test"])
P, h = train(data, mode="eq_opp", alpha=1.0, epochs=20)

res = pd.read_csv("results.csv", index_col=0)        # your sex results from main.py
res.loc["Debiased: equal opp."] = pd.Series(evaluate(P, *test))
pd.set_option("display.width", 250); pd.set_option("display.max_columns", None)
print(res.round(4))