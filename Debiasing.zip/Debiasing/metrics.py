
import numpy as np
import torch


@torch.no_grad()
def evaluate(predictor, X, y, z, threshold=0.5):
    predictor.eval()
    p = torch.sigmoid(predictor(X)).cpu().numpy()
    y, z = y.numpy(), z.numpy()
    if isinstance(threshold, tuple):        # Q12: (threshold for z=1, threshold for z=0)
        threshold = np.where(z == 1, threshold[0], threshold[1])
    yhat = (p >= threshold).astype(float)

    def rate(mask):
        return yhat[mask].mean() if mask.any() else np.nan

    return {
        "accuracy":  (yhat == y).mean(),
        "DP gap":    abs(rate(z == 1) - rate(z == 0)),
        "TPR gap":   abs(rate((z == 1) & (y == 1)) - rate((z == 0) & (y == 1))),
        "FPR gap":   abs(rate((z == 1) & (y == 0)) - rate((z == 0) & (y == 0))),
        "TPR z=1": rate((z == 1) & (y == 1)), "TPR z=0": rate((z == 0) & (y == 1)),
        "FPR z=1": rate((z == 1) & (y == 0)), "FPR z=0": rate((z == 0) & (y == 0)),
        "P(yhat=1|z=1)": rate(z == 1),
        "P(yhat=1|z=0)": rate(z == 0),
    }
