import pandas as pd
from data import load_adult
from train import train
from metrics import evaluate

data = load_adult()
test = (data["X_test"], data["y_test"], data["z_test"])
P, h = train(data, mode="eq_odds", alpha=1.0, epochs=20, alpha_schedule="sqrt")

res = pd.read_csv("results.csv", index_col=0)
res.loc["Debiased: A sees hidden layer"] = pd.Series(evaluate(P, *test))
pd.set_option("display.width", 250); pd.set_option("display.max_columns", None)
print(res.round(4))
print("\nStd over last 10 epochs:")
print(h[["accuracy", "DP gap", "TPR gap", "loss_A"]].tail(10).std().round(4))